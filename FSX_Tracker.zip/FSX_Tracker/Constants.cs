﻿namespace FSX_Tracker
{
    public static class Constants
    {
        public const int MaxZoom = 20;
        public const int MinZoom = 1;
        public const int ZoomStep = 1;
        public const int StartZoom = 10;
        public const int MaxChartXValue = 100;
    }
}
